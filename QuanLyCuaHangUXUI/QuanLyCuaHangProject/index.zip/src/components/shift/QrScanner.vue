<template>
  <div class="w-100 d-flex flex-row align-items-center">
    <div
      v-if="!showShiftTable"
      class="col d-flex justify-content-center flex-column align-items-center"
    >
      <div
        id="readerQr"
        @decode="onScanSuccess"
        style="width: 200px; height: 200px"
        :disabled="isDisabled"
      ></div>
      <p class="mt-2">Hoặc tải ảnh QR lên:</p>
      <div class="d-flex w-75 mb-2 align-items-center">
        <input
          type="file"
          @change="onFileUpload"
          accept="image/*"
          class="form-control col-9"
          :disabled="isDisabled"
        />
        <button
          class="btn btn-primary col-3"
          @click="confirmImageUpload"
          :disabled="!uploadedFile || isDisabled"
        >
          Xác nhận
        </button>
      </div>
    </div>
    <div v-if="showShiftTable" class="col border-left">
      <div v-if="loading" class="overlay">
        <div class="spinner-border text-primary" role="status">
          <span class="sr-only">Loading...</span>
        </div>
      </div>

      <div v-else class="mt-3">
        <h5>Nhân Viên cùng đăng kí Ca {{ employeeList[0].tenCa }}</h5>
        <div style="overflow-x: auto">
          <table class="table table-bordered mt-2" id="dt-employeeList">
            <thead>
              <tr>
                <th>Mã NV</th>
                <th>Tên Nhân Viên</th>
                <th>Giờ Vào</th>
                <th>Giờ Ra</th>
                <th>Trạng thái</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="employee in employeeList" :key="employee.maNv">
                <td>{{ employee.maNv }}</td>
                <td>{{ employee.tenNhanVien }}</td>
                <td>{{ formatTime(employee.gioVao) }}</td>
                <td>{{ formatTime(employee.gioRa) }}</td>
                <td>{{ employee.trangThai }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import jsQR from 'jsqr'
import { Html5Qrcode } from 'html5-qrcode'
import toastr from 'toastr'
import * as axiosConfig from '@/utils/axiosClient'
import ConfigsRequest from '@/models/ConfigsRequest'
import ResponseAPI from '@/models/ResponseAPI'
import { formatTime } from '@/constants/formatDatetime'

export default {
  name: 'QrScanner',
  // components: { QrcodeStream },
  data() {
    return {
      uploadedFile: null,
      showShiftTable: false,
      employeeList: [],
      isDisabled: false,
      loading: false, // Biến kiểm soát trạng thái
      html5Qrcode: null,
      lastScanTime: 0, // Thêm biến để theo dõi thời gian quét cuối
    }
  },
  async created() {
    await this.loadEmployeeSchedule() // Gọi API khi component được khởi tạo
  },
  mounted() {
    this.html5Qrcode = new Html5Qrcode('readerQr')
    this.html5Qrcode
      .start(
        { facingMode: 'environment' },
        {
          fps: 10,
          qrbox: { width: 200, height: 200 },
        },
        (decodedText, decodedResult) => {
          const currentTime = Date.now()
          // Kiểm tra xem đã đủ 5 giây kể từ lần quét cuối chưa
          if (currentTime - this.lastScanTime >= 5000) {
            this.lastScanTime = currentTime // Cập nhật thời gian quét
            this.onScanSuccess(decodedText)
          }
        },
        (errorMessage) => {
          console.log('Error: ', errorMessage)
        },
      )
      .catch((err) => {
        console.error(err)
      })
  },
  methods: {
    formatTime,
    async loadEmployeeSchedule() {
      this.loading = true

      try {
        const response = await axiosConfig.getFromApi(
          `/Schedule/GetScheduleActiveOfUser/`,
          ConfigsRequest.takeAuth(),
        )

        console.log(response)
        if (response.success && response.data.length > 0) {
          this.employeeList = response.data // Lưu danh sách nhân viên
          this.isDisabled = true // Disable các chức năng quét QR và tải ảnh
          this.showShiftTable = true // Hiển thị bảng nhân viên
        }
      } catch (error) {
        toastr.error('Lỗi khi tải danh sách nhân viên: ' + error.message)
      } finally {
        this.loading = false
      }
    },
    async onScanSuccess(qrCodeData) {
      try {
        const response = await axiosConfig.postToApi(
          `/Schedule/TimeKeeping?&qrCodeData=${encodeURIComponent(qrCodeData)}`,
          '',
          ConfigsRequest.takeAuth(),
        )

        if (ResponseAPI.handleNotification(response)) {
          return
        }

        // Sau khi quét QR thành công, lọc danh sách nhân viên trong ca
        const maCaKip = Number(qrCodeData.split('-')[0]) // ID ca làm việc từ mã QR
        this.filterEmployeesByShift(maCaKip)
      } catch (error) {
        Swal.fire({
          icon: 'error',
          title: 'Lỗi khi chấm công',
          text: error.message,
        });
      }
    },
    async onFileUpload(event) {
      const file = event.target.files[0]
      if (!file) return

      const reader = new FileReader()
      reader.onload = async (e) => {
        const img = new Image()
        img.src = e.target.result

        img.onload = async () => {
          try {
            const qrData = await this.decodeQrFromImage(img)
            this.onScanSuccess(qrData)
          } catch (error) {
            Swal.fire({
              icon: 'info',
              title: 'Thông báo',
              text: error.message,
            });

          }
        }
      }
      reader.readAsDataURL(file)
    },

    async confirmImageUpload() {
      if (!this.uploadedFile) return

      const reader = new FileReader()
      reader.onload = async (e) => {
        const img = new Image()
        img.src = e.target.result

        img.onload = async () => {
          try {
            const qrData = await this.decodeQrFromImage(img)
            this.onScanSuccess(qrData)
          } catch (error) {
            Swal.fire({
              icon: 'error',
              title: 'Lỗi',
              text: error.message,
            });
          }
        }
      }
      reader.readAsDataURL(this.uploadedFile)
    },
    decodeQrFromImage(image) {
      return new Promise((resolve, reject) => {
        const canvas = document.createElement('canvas')
        const ctx = canvas.getContext('2d')

        canvas.width = image.width
        canvas.height = image.height
        ctx.drawImage(image, 0, 0, image.width, image.height)

        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
        const code = jsQR(imageData.data, canvas.width, canvas.height)

        if (code) resolve(code.data)
        else reject(new Error('Không tìm thấy mã QR trong ảnh.'))
      })
    },
    async filterEmployeesByShift(maCaKip) {
      // Tìm ca làm việc dựa trên `maCaKip`
      const currentShift = this.listShifts.find((shift) => shift.maCaKip === maCaKip)

      if (currentShift) {
        // Lọc `schedules` chỉ lấy nhân viên có `trangThai === "Đi làm"`
        this.employeeList = (currentShift.schedules || []).filter(
          (employee) => employee.trangThai == 'Đi làm' || employee.trangThai == "Chờ xác nhận",
        )

        if (this.employeeList.length === 0) {
          toastr.info('Không có nhân viên nào đang đi làm trong ca này.')
        } else {
          this.showShiftTable = true // Hiển thị bảng nhân viên
        }
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Lỗi',
          text: 'Không tìm thấy ca làm việc tương ứng.',
        });
      }
    },
  },
}
</script>

<style scoped>
/* Các style liên quan đến quét QR */
</style>