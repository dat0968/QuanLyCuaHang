<template>
  <RouterLink class="text-link-format text-dark" to="/client-order" title="Đơn hàng khách hàng">
    <i class="icon-handbag"></i>
  </RouterLink>
</template>

<script>
export default {
  name: 'OrderClientButton',
  components: {},
  props: {},
  data() {
    return {}
  },
  computed: {},
  watch: {},
  mounted() {},
  methods: {},
}
</script>

<style scoped></style>
