const apiurl =  "https://api.jollibeefood.site";
// const apiurl =  "https://localhost:7139";
export const GetApiUrl = ()   =>{
    return apiurl;
    }

