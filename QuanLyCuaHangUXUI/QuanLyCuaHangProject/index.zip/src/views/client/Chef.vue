<script setup>
import OurExperienceChefs from '../../components/OurExperienceChefs.vue'
</script>
<template>
  <div>
    <!--::chefs_part start::-->
    <section class="chefs_part blog_item_section section_padding">
      <!-- breadcrumb start-->
      <section style="width: 100%" class="breadcrumb breadcrumb_bg">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="breadcrumb_iner text-center">
                <div class="breadcrumb_iner_item">
                  <h2>Đầu bếp giàu kinh nghiệm</h2>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- breadcrumb start-->

      <!--::chefs_part start::-->
      <OurExperienceChefs />
      <!--::chefs_part end::-->
    </section>
    <!--::chefs_part end::-->
  </div>
</template>

<style></style>
