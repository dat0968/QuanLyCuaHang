<template>
  <footer class="footer-area">
    <div class="container">
      <div class="row">
        <div class="col-xl-3 col-sm-6 col-md-3 col-lg-3">
          <div class="single-footer-widget footer_1">
            <h4>Về chúng tôi</h4>
            <p>
              Thiên đường không có kết quả cho những con nai hiệu quả trong nhiều ngày xuất hiện mùa
              leo lên những mùa buồn bã nhìn thấy beari ath của nó những dấu hiệu bay mang là một
              người may mắn sau đó.
            </p>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 col-md-2 col-lg-3">
          <div class="single-footer-widget footer_2">
            <h4>Liên kết quan trọng</h4>
            <div class="contact_info">
              <ul>
                <li><a href="#">WHMCS-cầu</a></li>
                <li><a href="#"> Tên miền tìm kiếm</a></li>
                <li><a href="#">Tài khoản của tôi</a></li>
                <li><a href="#">Giỏ hàng</a></li>
                <li><a href="#"> Cửa hàng của chúng tôi</a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 col-md-3 col-lg-3">
          <div class="single-footer-widget footer_2">
            <h4>Liên hệ</h4>
            <div class="contact_info">
              <p><span> Address :</span>Hath of it fly signs bear be one blessed after</p>
              <p><span> Phone :</span> +2 36 265 (8060)</p>
              <p><span> Email : </span>info@colorlib.com</p>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 col-md-4 col-lg-3">
          <div class="single-footer-widget footer_3">
            <h4>Bản tin</h4>
            <p>
              Thiên đường không có kết quả không quá ít hơn trong những ngày. Xuất hiện biển leo.
            </p>
            <form action="#">
              <div class="form-group">
                <div class="input-group mb-3">
                  <input
                    type="text"
                    class="form-control"
                    placeholder="Email Address"
                    onfocus="this.placeholder = ''"
                    onblur="this.placeholder = 'Email Address'"
                  />
                  <div class="input-group-append">
                    <button class="btn" type="button"><i class="fas fa-paper-plane"></i></button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div class="copyright_part_text">
        <div class="row">
          <div class="col-lg-8">
            <p class="footer-text m-0">
              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
              Copyright &copy;
              <!-- <script>
                  document.write(new Date().getFullYear());
                </script> -->
              All rights reserved | This template is made with
              <i class="ti-heart" aria-hidden="true"></i> by
              <a href="https://colorlib.com" target="_blank">Colorlib</a>
              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
          </div>
          <div class="col-lg-4">
            <div class="copyright_social_icon text-right">
              <a href="#"><i class="fab fa-facebook-f"></i></a>
              <a href="#"><i class="fab fa-twitter"></i></a>
              <a href="#"><i class="ti-dribbble"></i></a>
              <a href="#"><i class="fab fa-behance"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
</template>

<script>
export default {}
</script>

<style></style>
