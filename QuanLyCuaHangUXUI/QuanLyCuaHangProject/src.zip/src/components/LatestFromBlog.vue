<template>
  <!--::exclusive_item_part start::-->
  <section class="blog_item_section blog_section section_padding">
    <div class="container">
      <div class="row">
        <div class="col-xl-5">
          <div class="section_tittle">
            <p>Tin gần đây</p>
            <h2>Mới nhất từ ​​blog</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-6 col-lg-4">
          <div class="single_blog_item">
            <div class="single_blog_img">
              <img src="../assets/client/img/blog/blog_1.png" alt="" />
            </div>
            <div class="single_blog_text">
              <div class="date">
                <a href="#" class="date_item">Apr 06, 2019 </a>
                <a href="#" class="date_item"> <span>#</span> Tin tức </a>
              </div>
              <h3><a href="blog.html">Adama kind deep gatherin first over fter his great</a></h3>
              <a href="#" class="btn_3"
                >Xem thêm<img src="../assets/client/img/icon/left_1.svg" alt=""
              /></a>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-lg-4">
          <div class="single_blog_item">
            <div class="single_blog_img">
              <img src="../assets/client/img/blog/blog_2.png" alt="" />
            </div>
            <div class="single_blog_text">
              <div class="date">
                <a href="#" class="date_item">Apr 06, 2019 </a>
                <a href="#" class="date_item"> <span>#</span> Tin tức </a>
              </div>
              <h3><a href="blog.html">Adama kind deep gatherin first over fter his great</a></h3>
              <a href="#" class="btn_3"
                >Xem thêm<img src="../assets/client/img/icon/left_1.svg" alt=""
              /></a>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-lg-4">
          <div class="single_blog_item">
            <div class="single_blog_img">
              <img src="../assets/client/img/blog/blog_3.png" alt="" />
            </div>
            <div class="single_blog_text">
              <div class="date">
                <a href="#" class="date_item">Apr 06, 2019 </a>
                <a href="#" class="date_item"> <span>#</span> Tin tức </a>
              </div>
              <h3><a href="blog.html">Adama kind deep gatherin first over fter his great</a></h3>
              <a href="#" class="btn_3"
                >Xem thêm<img src="../assets/client/img/icon/left_1.svg" alt=""
              /></a>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-lg-4 d-none d-sm-block d-lg-none">
          <div class="single_blog_item">
            <div class="single_blog_img">
              <img src="../assets/client/img/blog/blog_1.png" alt="" />
            </div>
            <div class="single_blog_text">
              <div class="date">
                <a href="#" class="date_item">Apr 06, 2019 </a>
                <a href="#" class="date_item"> <span>#</span> Tin tức </a>
              </div>
              <h3><a href="blog.html">Adama kind deep gatherin first over fter his great</a></h3>
              <a href="#" class="btn_3"
                >Xem thêm<img src="../assets/client/img/icon/left_1.svg" alt=""
              /></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--::exclusive_item_part end::-->
</template>

<script>
export default {}
</script>

<style></style>
