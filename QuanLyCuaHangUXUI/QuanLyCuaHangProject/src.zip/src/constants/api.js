const apiurl =  "https://api.jollibeefood.site";
export const GetApiUrl = ()   =>{
    return apiurl;
    }

