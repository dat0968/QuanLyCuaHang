class StoreInfo {
  static COMPANY_NAME = 'CỬA HÀNG DARK BEE'
  static ADDRESS = '300, 6 đường Hà Huy Tập, BMT, Đắk Lắk'
  static PHONE_NUMBER = '0262 8884 375'
  static EMAIL = 'datntpk03691@gmail.com'
  static INVOICE_TITLE = 'HÓA ĐƠN BÁN HÀNG'
}

export default StoreInfo
