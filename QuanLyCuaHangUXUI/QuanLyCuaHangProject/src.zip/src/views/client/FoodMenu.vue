<script setup>
import DeliciousFoodMenu from '../../components/DeliciousFoodMenu.vue'
</script>
<template>
  <div>
    <!-- food_menu start-->
    <section class="food_menu">
      <!-- breadcrumb start-->
      <section style="width: 100%" class="breadcrumb breadcrumb_bg">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="breadcrumb_iner text-center">
                <div class="breadcrumb_iner_item">
                  <h2>Thực đơn đồ ăn</h2>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- breadcrumb start-->

      <!-- food_menu start-->
      <DeliciousFoodMenu />
      <!-- food_menu part end-->
    </section>
    <!-- food_menu part end-->
  </div>
</template>

<style></style>
